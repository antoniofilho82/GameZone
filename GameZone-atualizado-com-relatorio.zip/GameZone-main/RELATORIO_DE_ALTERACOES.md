# Relatório de Desenvolvimento e Alterações — GameZone

Este relatório resume as alterações atualmente presentes no projeto, incluindo interface, navegação, filtros, catálogo, integração CheapShark, tipagem e documentação do código.

---

## 1. Ajustes visuais e componentes de interface

### GameCard
- A capa usa um container proporcional `460 / 215`, fundo escuro `#0b0b10` e `object-fit: contain`, para preservar a arte completa sem distorção.
- A URL de imagem retornada pela CheapShark é usada diretamente, sem substituir nomes de arquivo.
- As grades da Home e do Catálogo usam colunas responsivas com largura mínima de 240px e espaçamento de 1.25rem.

### HeroBanner
- A rotação prioriza jogos marcados como destaque e limita a lista a até seis slides.
- O autoplay troca de slide a cada oito segundos e reinicia após uma alteração manual; o intervalo é limpo ao desmontar ou atualizar o efeito.
- As zonas de navegação laterais são independentes, com gradiente escuro discreto. O círculo da seta só fica roxo quando o ponteiro está diretamente sobre ele.
- Setas e indicadores permitem avançar, retroceder ou escolher o slide.

### Header
- A busca sugere até seis jogos por título, apresentando miniatura, nome e preço em reais.
- Selecionar uma sugestão abre os detalhes do jogo. A lista fecha ao clicar fora ou pressionar Escape.

---

## 2. Navegação e páginas

### Rolagem ao topo
- O componente `ScrollToTop` está integrado ao roteador e rola a página ao topo quando mudam o caminho ou a query string da URL.

### Ofertas
- A rota `/ofertas` carrega jogos pelo serviço, mostra estado de carregamento e mensagem vazia, e renderiza cards dos itens marcados como oferta.

### Home
- A seção “Ofertas Imperdíveis” exibe no máximo seis cards.
- Categorias e destaques continuam ligados aos respectivos filtros e slides.

---

## 3. Catálogo, filtros e dados

### Carregamento e paginação
- `getGames()` solicita até 60 ofertas da CheapShark e mescla os resultados aos mocks locais, priorizando a versão da API e removendo duplicatas por título normalizado.
- O Catálogo aplica busca, gênero e plataforma ao conjunto atualmente carregado antes de limitar a exibição.
- A lista começa com 20 cards; “Carregar mais” revela os próximos 20 da lista já carregada. Os filtros e a ordenação reiniciam a quantidade visível.
- O serviço também expõe `getGamesPage()` para solicitar páginas. `X-Total-Count` fornece a contagem exata quando disponível; `X-Total-Page-Count` é usado apenas para indicar se há mais páginas, pois não informa quantos itens existem na última página.

### Gêneros
- Jogos da API recebem um gênero inferido por palavras-chave ou por hash determinístico do título, para que o resultado não varie conforme a ordem da página.
- O filtro especial “Ofertas” considera a marcação de oferta ou um desconto real; “Todos os gêneros” não restringe a lista.

### Plataformas
- O tipo `Platform` inclui PC, PlayStation, Xbox, Nintendo e Mobile.
- Os dados demonstrativos incluem essas plataformas; a antiga etiqueta PS5 foi normalizada para PlayStation.
- Os filtros de consoles e Mobile podem combinar dados da API com jogos locais, eliminando duplicatas por título normalizado.

---

## 4. Tipos e documentação do código

- Componentes e páginas receberam documentação de responsabilidade e comportamento; props públicas relevantes também foram descritas.
- Hooks com efeitos não óbvios — autocomplete, fechamento da busca, rotação do banner e filtros do Catálogo — receberam comentários explicativos.
- Funções do serviço CheapShark e estruturas de resposta foram documentadas, incluindo enriquecimento de gênero, validação de preços, mesclagem e paginação.
- Tipos de domínio mantêm descrições de seus campos, e o cliente HTTP compartilhado foi identificado.
- As folhas CSS receberam comentários de seção para localizar mais facilmente estilos globais, componentes e páginas.

---

## 5. Limites observados na implementação atual

- A tela do Catálogo usa `getGames()`, que carrega até 60 resultados da API mais os mocks. O botão revela mais itens desse conjunto carregado; atualmente não solicita páginas adicionais à API.
- O contador do Catálogo mostra quantos cards estão visíveis, não o total global da CheapShark. A API pode fornecer o total exato pelo header `X-Total-Count`; `X-Total-Page-Count` sozinho não é tratado como contagem exata, e nenhum desses metadados está conectado ao contador atual da tela.
- Como os gêneros dos resultados da CheapShark são inferidos pelo título, representam uma classificação demonstrativa, não metadados oficiais da loja.
- Os fluxos de autenticação, pagamento e chaves de ativação permanecem demonstrativos/client-side, conforme a documentação do projeto.

---

## 6. Validação da versão anterior

- A versão de referência do projeto registrava a execução de `npm run lint` e `npm run build`.
- A validação específica das alterações desta revisão está registrada na seção 7.


---

## 7. Melhorias de autenticação e compatibilidade de ambiente (09/11/2026)

### Tela de login e cadastro
- A página `src/pages/Auth.tsx` recebeu uma nova composição em duas colunas: apresentação da GameZone e cartão de autenticação.
- O visual passou a usar os tokens do tema Dark Gaming, elementos de destaque roxo, ícones e adaptação específica para telas menores.
- Foram adicionados links para voltar à loja, descrição dos recursos disponíveis e um aviso explícito de que a autenticação é demonstrativa.
- A rota `/login` foi retirada do `MainLayout` e passou a usar um layout próprio, sem o cabeçalho e o rodapé globais. Os demais caminhos da loja continuam usando o layout compartilhado.
- A navegação de retorno (`location.state.from`) foi preservada, inclusive o fluxo carrinho → login → checkout.

### Validação e acessibilidade
- E-mail salvo no perfil demonstrativo pode ser sugerido no próximo acesso.
- O formulário mantém validação de e-mail, senha mínima, nome e confirmação de senha; as mensagens de erro são associadas aos campos e removidas conforme o usuário corrige cada entrada.
- O botão de exibir/ocultar senha possui rótulo acessível e estado anunciado. O feedback de conclusão usa região de status.
- A senha continua fora do `localStorage`; somente o perfil de exibição (ID, nome e e-mail) é gravado. O login não é validado por servidor e não representa autenticação real.

### Requisitos de execução do PDF
- Conferidos os pontos do guia: projeto React + Vite + TypeScript, `index.html`, `src/main.tsx`, `src/App.tsx`, arquivos `tsconfig*.json`, `package.json`, instalação por npm, execução com `npm run dev` e scripts `build`/`preview`.
- Ajuste de compatibilidade: o guia de referência recomenda Node.js 18+, porém o Vite 8.3.6 presente no `package-lock.json` declara `^20.19.0 || >=22.12.0`. A exigência efetiva foi registrada em `package.json` (`engines.node`) e na raiz do `package-lock.json`.

### Melhorias recomendadas para uma versão real
- Implementar uma API de autenticação e banco de dados com armazenamento seguro de senha por hash, sessões/token, encerramento de sessão e recuperação de senha.
- Proteger o checkout e os dados da conta no servidor; a validação client-side atual existe apenas para demonstrar navegação e UX.

### Resultado da validação desta revisão
- `npm ci` foi iniciado, mas não pôde concluir porque o ambiente não conseguiu resolver `registry.npmjs.org` (`EAI_AGAIN`).
- Por esse motivo, `npm run lint` e `npm run build` não puderam ser executados nesta revisão. Não foi considerado correto declarar o build como aprovado sem as dependências instaladas.
- Foram conferidos os arquivos e as rotas alteradas, a sintaxe TSX foi analisada com o compilador TypeScript disponível no ambiente, e os arquivos JSON foram validados.
- Após baixar as dependências em uma máquina com acesso ao npm, execute `npm install`, `npm run lint` e `npm run build` antes da apresentação/entrega acadêmica.

## 8. Relação dos arquivos alterados nesta revisão

A comparação entre o projeto original (`GameZone-main.zip`) e a versão atualizada (`GameZone-atualizado.zip`) identificou os seguintes arquivos modificados:

### 8.1 Arquivos de implementação

| Arquivo | Alteração realizada |
| --- | --- |
| `src/pages/Auth.tsx` | Reestruturação da tela de autenticação, incluindo apresentação da loja, alternância entre login e cadastro, campos, validações, mensagens de feedback e controles acessíveis para exibir/ocultar a senha. |
| `src/pages/Auth.css` | Reformulação visual da autenticação: layout em duas colunas, identidade visual Dark Gaming, destaques roxos, ajustes de espaçamento e regras responsivas para telas menores. |
| `src/App.tsx` | Ajuste das rotas para que `/login` utilize um layout independente, sem o cabeçalho e o rodapé globais, preservando as demais páginas dentro do `MainLayout`. |

### 8.2 Arquivos de configuração

| Arquivo | Alteração realizada |
| --- | --- |
| `package.json` | Inclusão da propriedade `engines.node` para declarar a versão mínima compatível com o Vite instalado: `^20.19.0 || >=22.12.0`. |
| `package-lock.json` | Atualização dos metadados do projeto para refletir a exigência de versão do Node.js registrada no `package.json`. |

### 8.3 Arquivos de documentação

| Arquivo | Alteração realizada |
| --- | --- |
| `README.md` | Atualização das instruções do projeto, incluindo pré-requisitos e comandos de instalação, validação e execução. |
| `RELATORIO_DE_ALTERACOES.md` | Registro das melhorias realizadas, limitações, validações e relação dos arquivos modificados nesta revisão. |
| `Relatorio_Tecnico.md` | Atualização do relatório técnico para documentar as mudanças de autenticação e compatibilidade do ambiente. |

**Total: 8 arquivos modificados** — 3 de implementação, 2 de configuração e 3 de documentação.

> Os demais arquivos do projeto foram mantidos sem alterações nesta revisão.
