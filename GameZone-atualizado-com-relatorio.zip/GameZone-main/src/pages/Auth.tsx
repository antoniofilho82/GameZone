import { useEffect, useState, type FormEvent } from 'react'
import { Link, useLocation, useNavigate, type To } from 'react-router-dom'
import {
  ArrowLeft,
  Eye,
  EyeOff,
  Gamepad2,
  Heart,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Tag,
  UserRound,
} from 'lucide-react'

import type { User } from '../types/user'

import './Auth.css'

const USER_STORAGE_KEY = 'gamezone-user'

type AuthMode = 'login' | 'register'
type AuthField = 'name' | 'email' | 'password' | 'confirmPassword'
type AuthErrors = Partial<Record<AuthField, string>>

interface AuthLocationState {
  from?: To
}

/** Lê o perfil local quando válido, sem acessar ou armazenar qualquer senha. */
function readStoredUser(): User | null {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(USER_STORAGE_KEY) ?? 'null')

    if (
      typeof value === 'object' &&
      value !== null &&
      'id' in value &&
      typeof value.id === 'string' &&
      'name' in value &&
      typeof value.name === 'string' &&
      'email' in value &&
      typeof value.email === 'string'
    ) {
      return { id: value.id, name: value.name, email: value.email }
    }
  } catch (error) {
    console.error('Não foi possível ler o perfil demonstrativo salvo.', error)
  }

  return null
}

/** Tela responsiva de acesso e cadastro para o protótipo acadêmico GameZone. */
function Auth() {
  const [mode, setMode] = useState<AuthMode>('login')
  const [email, setEmail] = useState(() => readStoredUser()?.email ?? '')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [isPasswordVisible, setIsPasswordVisible] = useState(false)
  const [errors, setErrors] = useState<AuthErrors>({})
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [storageError, setStorageError] = useState('')
  const location = useLocation() as ReturnType<typeof useLocation> & {
    state: AuthLocationState | null
  }
  const navigate = useNavigate()
  const redirectTo = location.state?.from || '/'

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  useEffect(() => {
    if (!isSubmitted) {
      return
    }

    const timeoutId = window.setTimeout(() => navigate(redirectTo, { replace: true }), 900)
    return () => window.clearTimeout(timeoutId)
  }, [isSubmitted, navigate, redirectTo])

  function handleChangeMode(nextMode: AuthMode) {
    setMode(nextMode)
    setErrors({})
    setIsSubmitted(false)
    setStorageError('')
    setIsPasswordVisible(false)
  }

  function validateForm(): AuthErrors {
    const nextErrors: AuthErrors = {}
    const normalizedEmail = email.trim()

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      nextErrors.email = 'Informe um endereço de e-mail válido.'
    }

    if (password.length < 6) {
      nextErrors.password = 'A senha precisa ter pelo menos 6 caracteres.'
    }

    if (mode === 'register') {
      if (name.trim().length === 0) {
        nextErrors.name = 'Informe seu nome para continuar.'
      }

      if (confirmPassword !== password) {
        nextErrors.confirmPassword = 'As senhas informadas não coincidem.'
      }
    }

    return nextErrors
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setStorageError('')
    const nextErrors = validateForm()
    setErrors(nextErrors)

    if (Object.keys(nextErrors).length > 0) {
      return
    }

    const normalizedEmail = email.trim().toLowerCase()
    const existingUser = readStoredUser()
    const user: User = {
      id: normalizedEmail,
      name:
        mode === 'register'
          ? name.trim()
          : existingUser?.email === normalizedEmail
            ? existingUser.name
            : normalizedEmail.split('@')[0],
      email: normalizedEmail,
    }

    try {
      // O protótipo salva apenas o perfil de exibição; a senha nunca é persistida.
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user))
      setStorageError('')
      setIsSubmitted(true)
    } catch (error) {
      console.error('Não foi possível salvar o perfil demonstrativo.', error)
      setStorageError('Não foi possível salvar seu acesso neste navegador. Tente novamente.')
    }
  }

  function clearFieldError(field: AuthField) {
    setErrors((currentErrors) => ({ ...currentErrors, [field]: undefined }))
    setIsSubmitted(false)
  }

  const title = mode === 'login' ? 'Que bom ter você de volta!' : 'Crie sua conta'

  return (
    <main className="auth-page">
      <div className="auth-page__glow auth-page__glow--one" aria-hidden="true" />
      <div className="auth-page__glow auth-page__glow--two" aria-hidden="true" />

      <div className="auth-shell">
        <section className="auth-intro" aria-labelledby="auth-promo-title">
          <Link className="auth-brand" to="/" aria-label="GameZone - voltar ao início">
            <span className="auth-brand__icon">
              <Gamepad2 size={25} aria-hidden="true" />
            </span>
            <span>
              Game<span>Zone</span>
            </span>
          </Link>

          <div className="auth-intro__content">
            <span className="auth-intro__eyebrow">
              <span className="auth-intro__eyebrow-dot" />
              SUA LOJA, SEU PRÓXIMO JOGO
            </span>
            <h1 id="auth-promo-title">
              Entre no jogo.
              <span>Descubra seu próximo mundo.</span>
            </h1>
            <p className="auth-intro__description">
              Acesse sua conta GameZone e deixe suas próximas aventuras sempre por perto.
            </p>

            <div className="auth-benefits" aria-label="Recursos da GameZone">
              <div className="auth-benefit">
                <span className="auth-benefit__icon"><Tag size={19} aria-hidden="true" /></span>
                <span>
                  <strong>Ofertas para explorar</strong>
                  <small>Encontre novos jogos e promoções.</small>
                </span>
              </div>
              <div className="auth-benefit">
                <span className="auth-benefit__icon"><Heart size={19} aria-hidden="true" /></span>
                <span>
                  <strong>Sua lista de desejos</strong>
                  <small>Guarde os títulos que chamaram sua atenção.</small>
                </span>
              </div>
              <div className="auth-benefit">
                <span className="auth-benefit__icon"><ShieldCheck size={19} aria-hidden="true" /></span>
                <span>
                  <strong>Experiência simples</strong>
                  <small>Catálogo, favoritos e carrinho em um só lugar.</small>
                </span>
              </div>
            </div>
          </div>

          <p className="auth-intro__footer">GAMEZONE STORE <span>•</span> PROJETO ACADÊMICO</p>
        </section>

        <section className="auth-card" aria-labelledby="auth-title">
          <Link className="auth-card__back" to="/">
            <ArrowLeft size={16} aria-hidden="true" />
            Voltar para a loja
          </Link>

          <header className="auth-card__heading">
            <span className="auth-card__eyebrow">SUA CONTA GAMEZONE</span>
            <h2 id="auth-title">{title}</h2>
            <p>
              {mode === 'login'
                ? 'Entre com seus dados para continuar.'
                : 'Preencha os campos abaixo para começar.'}
            </p>
          </header>

          <div className="auth-tabs" role="tablist" aria-label="Tipo de acesso">
            <button
              className={`auth-tabs__tab${mode === 'login' ? ' auth-tabs__tab--active' : ''}`}
              id="auth-login-tab"
              type="button"
              role="tab"
              aria-selected={mode === 'login'}
              aria-controls="auth-form-panel"
              onClick={() => handleChangeMode('login')}
            >
              Entrar
            </button>
            <button
              className={`auth-tabs__tab${mode === 'register' ? ' auth-tabs__tab--active' : ''}`}
              id="auth-register-tab"
              type="button"
              role="tab"
              aria-selected={mode === 'register'}
              aria-controls="auth-form-panel"
              onClick={() => handleChangeMode('register')}
            >
              Criar conta
            </button>
          </div>

          <form
            className="auth-form"
            id="auth-form-panel"
            role="tabpanel"
            aria-labelledby={mode === 'login' ? 'auth-login-tab' : 'auth-register-tab'}
            noValidate
            onSubmit={handleSubmit}
          >
            {mode === 'register' && (
              <div className="auth-form__field">
                <label htmlFor="auth-name">Nome completo</label>
                <div className={`auth-form__input${errors.name ? ' auth-form__input--error' : ''}`}>
                  <UserRound size={18} aria-hidden="true" />
                  <input
                    id="auth-name"
                    name="name"
                    type="text"
                    autoComplete="name"
                    placeholder="Como podemos chamar você?"
                    value={name}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'auth-name-error' : undefined}
                    onChange={(event) => {
                      setName(event.currentTarget.value)
                      clearFieldError('name')
                    }}
                    required
                  />
                </div>
                {errors.name && <p className="auth-form__error" id="auth-name-error">{errors.name}</p>}
              </div>
            )}

            <div className="auth-form__field">
              <label htmlFor="auth-email">E-mail</label>
              <div className={`auth-form__input${errors.email ? ' auth-form__input--error' : ''}`}>
                <Mail size={18} aria-hidden="true" />
                <input
                  id="auth-email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  placeholder="voce@exemplo.com"
                  value={email}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'auth-email-error' : undefined}
                  onChange={(event) => {
                    setEmail(event.currentTarget.value)
                    clearFieldError('email')
                  }}
                  required
                />
              </div>
              {errors.email && <p className="auth-form__error" id="auth-email-error">{errors.email}</p>}
            </div>

            <div className="auth-form__field">
              <label htmlFor="auth-password">Senha</label>
              <div className={`auth-form__input${errors.password ? ' auth-form__input--error' : ''}`}>
                <LockKeyhole size={18} aria-hidden="true" />
                <input
                  id="auth-password"
                  name="password"
                  type={isPasswordVisible ? 'text' : 'password'}
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  placeholder="Digite sua senha"
                  value={password}
                  aria-invalid={Boolean(errors.password)}
                  aria-describedby={[
                    errors.password ? 'auth-password-error' : '',
                    mode === 'login' ? 'auth-password-hint' : '',
                  ].filter(Boolean).join(' ') || undefined}
                  onChange={(event) => {
                    setPassword(event.currentTarget.value)
                    clearFieldError('password')
                  }}
                  required
                  minLength={6}
                />
                <button
                  className="auth-form__visibility"
                  type="button"
                  aria-label={isPasswordVisible ? 'Ocultar senha' : 'Mostrar senha'}
                  aria-pressed={isPasswordVisible}
                  onClick={() => setIsPasswordVisible((visible) => !visible)}
                >
                  {isPasswordVisible ? <EyeOff size={18} aria-hidden="true" /> : <Eye size={18} aria-hidden="true" />}
                </button>
              </div>
              {errors.password && <p className="auth-form__error" id="auth-password-error">{errors.password}</p>}
              {mode === 'login' && (
                <span className="auth-form__hint" id="auth-password-hint">
                  Use uma senha com pelo menos 6 caracteres.
                </span>
              )}
            </div>

            {mode === 'register' && (
              <div className="auth-form__field">
                <label htmlFor="auth-confirm-password">Confirmar senha</label>
                <div className={`auth-form__input${errors.confirmPassword ? ' auth-form__input--error' : ''}`}>
                  <LockKeyhole size={18} aria-hidden="true" />
                  <input
                    id="auth-confirm-password"
                    name="confirmPassword"
                    type={isPasswordVisible ? 'text' : 'password'}
                    autoComplete="new-password"
                    placeholder="Digite a senha novamente"
                    value={confirmPassword}
                    aria-invalid={Boolean(errors.confirmPassword)}
                    aria-describedby={errors.confirmPassword ? 'auth-confirm-password-error' : undefined}
                    onChange={(event) => {
                      setConfirmPassword(event.currentTarget.value)
                      clearFieldError('confirmPassword')
                    }}
                    required
                    minLength={6}
                  />
                </div>
                {errors.confirmPassword && (
                  <p className="auth-form__error" id="auth-confirm-password-error">{errors.confirmPassword}</p>
                )}
              </div>
            )}

            {isSubmitted && (
              <p className="auth-form__success" role="status" aria-live="polite">
                Acesso demonstrativo confirmado. Redirecionando...
              </p>
            )}
            {storageError && <p className="auth-form__error" role="alert">{storageError}</p>}

            <button className="auth-form__submit" type="submit" disabled={isSubmitted}>
              {isSubmitted ? 'Aguarde...' : mode === 'login' ? 'Entrar na GameZone' : 'Criar minha conta'}
            </button>
          </form>

          <div className="auth-card__notice">
            <ShieldCheck size={16} aria-hidden="true" />
            <p>
              <strong>Ambiente demonstrativo.</strong> Este acesso é simulado no navegador. Sua senha
              não é armazenada e não há autenticação por servidor.
            </p>
          </div>
        </section>
      </div>
    </main>
  )
}

export default Auth
